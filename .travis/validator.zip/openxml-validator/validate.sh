/usr/local/share/dotnet/dotnet bin/Debug/netcoreapp3.0/Program.dll test.docx
#dotnet bin/Debug/netcoreapp3.0/Program.dll --xlsx test.xlsx
#/usr/local/share/dotnet/dotnet bin/Debug/netcoreapp3.0/Program.dll --pptx test.potx
