# openxml-validator

Supports DOCX (--docx) default, XLSX (--xlsx), PPTX (--pptx) modes.

Building:
```bash
GitHub/openxml-validator$ dotnet build
Microsoft (R) Build Engine version 16.3.0+0f4c62fea for .NET Core
Copyright (C) Microsoft Corporation. All rights reserved.

  Restore completed in 89.75 ms for /mnt/c/Users/ghall/Documents/GitHub/openxml-validator/Program.csproj.
  Program -> /mnt/c/Users/ghall/Documents/GitHub/openxml-validator/bin/Debug/netcoreapp3.0/Program.dll

Build succeeded.
    0 Warning(s)
    0 Error(s)

Time Elapsed 00:00:02.64
```

Running:
```bash
$ dotnet bin/Debug/netcoreapp3.0/Program.dll ~/wh/outputs/unioffice/2019-10-21/document_new.docx
Processing: /home/ghall/wh/outputs/unioffice/2019-10-21/document_new.docx
Document is not valid

Error description: The attribute 'pid' has invalid value '0'. The MinInclusive constraint failed. The value must be greater than or equal to 2.
Content type of part with error: application/vnd.openxmlformats-officedocument.custom-properties+xml
Location of error: /op:Properties[1]/op:property[1]
Error description: The attribute 'pid' has invalid value '0'. The MinInclusive constraint failed. The value must be greater than or equal to 2.
Content type of part with error: application/vnd.openxmlformats-officedocument.custom-properties+xml
Location of error: /op:Properties[1]/op:property[2]
Error description: The attribute 'pid' has invalid value '0'. The MinInclusive constraint failed. The value must be greater than or equal to 2.
Content type of part with error: application/vnd.openxmlformats-officedocument.custom-properties+xml
Location of error: /op:Properties[1]/op:property[3]
Error description: The attribute 'pid' has invalid value '0'. The MinInclusive constraint failed. The value must be greater than or equal to 2.
Content type of part with error: application/vnd.openxmlformats-officedocument.custom-properties+xml
Location of error: /op:Properties[1]/op:property[4]
```

```
$ dotnet bin/Debug/netcoreapp3.0/Program.dll --xlsx ~/wh/Downloads/formulas.xlsx
Processing: /home/ghall/wh/Downloads/formulas.xlsx
XLSX File: /home/ghall/wh/Downloads/formulas.xlsx
Document is valid
```
